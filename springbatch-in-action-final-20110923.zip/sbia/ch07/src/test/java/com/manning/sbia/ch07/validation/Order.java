/**
 * 
 */
package com.manning.sbia.ch07.validation;

/**
 * Dummy class not annotated with JSR 303 annotations.
 * @author acogoluegnes
 *
 */
public class Order {

	private Long id = 1L;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	
	
}
