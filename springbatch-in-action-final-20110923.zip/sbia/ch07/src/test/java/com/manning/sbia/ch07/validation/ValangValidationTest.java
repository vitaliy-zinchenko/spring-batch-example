/**
 * 
 */
package com.manning.sbia.ch07.validation;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author acogoluegnes
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class ValangValidationTest extends DeclarativeValidationBaseTest {

	
	
}
