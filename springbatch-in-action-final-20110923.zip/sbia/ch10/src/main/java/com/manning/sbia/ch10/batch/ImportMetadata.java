/**
 * 
 */
package com.manning.sbia.ch10.batch;

/**
 * @author acogoluegnes
 *
 */
public class ImportMetadata {

	private String importId;

	public String getImportId() {
		return importId;
	}

	public void setImportId(String importId) {
		this.importId = importId;
	}
	
}
