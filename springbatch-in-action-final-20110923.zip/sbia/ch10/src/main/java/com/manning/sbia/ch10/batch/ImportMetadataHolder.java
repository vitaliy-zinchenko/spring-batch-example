/**
 * 
 */
package com.manning.sbia.ch10.batch;

/**
 * @author acogoluegnes
 *
 */
public class ImportMetadataHolder {
	
	private ImportMetadata importMetadata;

	public ImportMetadata get() {
		return importMetadata;
	}

	public void set(ImportMetadata importMetadata) {
		this.importMetadata = importMetadata;
	}
	
}
