create table orders (
	order_id character varying(9),
	shipped boolean
);