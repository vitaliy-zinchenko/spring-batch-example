/**
 * 
 */
package com.manning.sbia.ch11.integration;


/**
 * @author acogoluegnes
 *
 */
public interface ProductImportGateway {

	void importProducts(String content);
	
}
