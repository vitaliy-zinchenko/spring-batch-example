/**
 * 
 */
package com.manning.sbia.ch08;

/**
 * @author acogoluegnes
 *
 */
public interface BusinessService {
	
	String reading();

	void writing(String item);
	
	void processing(String item);
	
}
