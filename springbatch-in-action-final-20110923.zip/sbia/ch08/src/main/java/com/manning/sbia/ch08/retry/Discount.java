/**
 * 
 */
package com.manning.sbia.ch08.retry;

/**
 * @author acogoluegnes
 *
 */
public class Discount {

}
