/**
 * 
 */
package com.manning.sbia.ch08.retry;

import java.util.List;

/**
 * @author acogoluegnes
 *
 */
public class DiscountsHolder {

	private List<Discount> discounts;

	public List<Discount> getDiscounts() {
		return discounts;
	}

	public void setDiscounts(List<Discount> discounts) {
		this.discounts = discounts;
	}
	
}
