/**
 * 
 */
package com.manning.sbia.ch08.retry;

import java.util.List;

/**
 * @author acogoluegnes
 *
 */
public interface DiscountService {

	List<Discount> getDiscounts();
	
}
