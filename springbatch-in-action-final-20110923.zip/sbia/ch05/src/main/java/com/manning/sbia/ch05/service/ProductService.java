package com.manning.sbia.ch05.service;

import java.util.List;
import java.util.ArrayList;

import com.manning.sbia.ch05.Product;

public interface ProductService {
	List<Product> getProducts();
}
